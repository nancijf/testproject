//
//  ErrorResponse.swift
//  NetworkKit
//
//  Created by Sulabh Agarwal
//

import Foundation

public enum ErrorResponse:Error {
    case invalidEndpoint
    case ResponseError
    case DataParsingError
    case ResponseCodeError
}
