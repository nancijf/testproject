import Foundation

/// A protocol defining a data request.
public protocol DataRequest {
    /// The associated type representing the response of the request.
    associatedtype Response
    
    /// The URL of the request.
    var url: String { get }
    
    /// The HTTP method of the request.
    var method: HTTPMethod { get }
    
    /// The headers of the request.
    var headers: [String : String] { get }
    
    /// The query items of the request.
    var queryItems: [String : String] { get }
    
    /// Decode the data response of the request.
    func decode(_ data: Data) throws -> Response
}

public extension DataRequest {
    var headers: [String : String] {
        [:]
    }
    
    var queryItems: [String : String] {
        [:]
    }
}

public extension DataRequest where Response: Decodable {
    /// Decode the data response of the request using JSONDecoder.
    func decode(_ data: Data) throws -> Response {
        let decoder = JSONDecoder()
        return try decoder.decode(Response.self, from: data)
    }
}

/// A protocol defining a network service for making data requests.
public protocol NetworkService {
    /// Perform a data request asynchronously.
    func request<Request: DataRequest>(_ request: Request) async throws -> Result<Request.Response, Error>
}

/// The default implementation of NetworkService.
public class DefaultNetworkService: NetworkService {
    
    /// Initializes the DefaultNetworkService.
    public init() { }

    /// Perform a data request asynchronously.
    ///
    /// - Parameters:
    ///   - request: The data request to perform.
    /// - Returns: A result containing either the response data or an error.
    public func request<Request: DataRequest>(_ request: Request) async throws -> Result<Request.Response, Error> {
        // Construct URL components
        guard var urlComponent = URLComponents(string: request.url) else {
            throw ErrorResponse.invalidEndpoint
        }
        
        // Construct URL query items
        var queryItems: [URLQueryItem] = []
        request.queryItems.forEach {
            let urlQueryItem = URLQueryItem(name: $0.key, value: $0.value)
            urlComponent.queryItems?.append(urlQueryItem)
            queryItems.append(urlQueryItem)
        }
        urlComponent.queryItems = queryItems

        // Validate URL
        guard let url = urlComponent.url else {
            throw ErrorResponse.invalidEndpoint
        }

        // Create URL request
        var urlRequest = URLRequest(url: url)
        urlRequest.httpMethod = request.method.rawValue
        urlRequest.allHTTPHeaderFields = request.headers

        // Perform network request
        let (data, response) = try await URLSession.shared.data(for: urlRequest)
        
        // Validate HTTP response
        guard let httpResponse = response as? HTTPURLResponse, 200..<300 ~= httpResponse.statusCode else {
            throw ErrorResponse.ResponseError
        }
        
        // Decode response data
        do {
            return .success(try request.decode(data))
        } catch let error as NSError {
            throw error
        }
    }
}
