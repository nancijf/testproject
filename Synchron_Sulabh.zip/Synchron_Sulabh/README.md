# Synchrony Coding Challenge 
Author: Sulabh Agarwal
sulabh191@gmail.com


The goal of project is to implement

1.  Fetch a list of cat api data in JSON format from this URL: 
2.  Display all the data in a UITableView ordered by the position they appear in the JSON. 
3.  Create my profile and show in scrollable section , added in app nav bar

To Run The project:
Open the project folder and then open : xcworkspace
Run should be able to run in apple - ios simulator

The project is  implemented as per MVVM architecture. 

Some of main components used
- `ListViewController`: first controller where list is displayed
- `ListViewModel`: provides view model and functions needed for controller
- `CatService<CatServiceProtocol>`: adhered to service protocol to invoke api for fetching list 
- `CatViewCell`: provides view for list 
- `Profile`: provides view for my profile using swiftUI
- `UIView+ReuseIdentifier`: provides a simple `reuseIdentifier` pattern for `UITableViewCell` 
- `AppCoordinator` : Coordintor responsible for app navigation flow

