//
//  AppDelegate.swift
//  Created by Sulabh Agarwal

import UIKit

@main
class AppDelegate: UIResponder, UIApplicationDelegate {

    var window: UIWindow?
    var coordinator: AppCoordinator?

    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
        // Override point for customization after application launch.
        window = UIWindow()
        coordinator = AppCoordinator(navigationController: UINavigationController(), window: window!)
        coordinator?.start()
        return true
    }
}

