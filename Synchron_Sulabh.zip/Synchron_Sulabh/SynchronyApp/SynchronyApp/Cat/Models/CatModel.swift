//
//  CatModel.swift
//  SynchronyApp
//
//  Created by Sulabh Agarwal on 6/9/24.
//

import Foundation

typealias CatList = [CatBreed]

/// Data Model for Cat api response
struct CatBreed: Decodable, Hashable {
    /// internal ID
    let id: String?
    
    /// Name of cat (e.g. "Somali")
    let name: String?
    
    /// Description
    let description: String?
    
    /// Range (e.g. 12-16)
    let life_span: String?
    let temperament, origin:String?
    /// Reference
    let wikipedia_url: String?
    
    /// General traits and characteristic rankings (0-10)
    let adaptability: Int?
    let affection_level: Int?
    let child_friendly: Int?
    let dog_friendly: Int?
    let energy_level: Int?
    let grooming: Int?
    let health_issues: Int?
    let intelligence: Int?
    let shedding_level: Int?
    let social_needs: Int?
    let stranger_friendly: Int?
    let vocalisation: Int?
}
