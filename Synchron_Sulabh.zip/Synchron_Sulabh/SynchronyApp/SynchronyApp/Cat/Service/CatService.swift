//
//  CatService.swift
//  SynchronyApp
//
//  Created by Sulabh Agarwal on 6/9/24.

import Foundation
import NetworkKit

protocol CatServiceProtocol {
    func fetchCatList(page: Int, limit: Int) async throws-> CatServiceApiRequest.Response
}

// Requests
struct CatServiceApiRequest : DataRequest {
    var page: Int
    var limit: Int
    var bodyData: Data?
    var body: [String : Any] = [:]
    var queryItems: [String: String] {
        return [
            "limit": "\(limit)",
            "page": "\(page)"
        ]
    }
    var headers: [String : String] = ["Content-Type": "application/json"]
    var breedId: String = ""
    var url: String  {
        let baseURL: String = "https://api.thecatapi.com/v1/breeds"
        return baseURL
    }
    
    var method: HTTPMethod {
        return .get
    }
    
    typealias Response = CatList
}


class CatService: CatServiceProtocol {
    let networkService = DefaultNetworkService()

    func fetchCatList(page: Int, limit: Int) async throws-> CatServiceApiRequest.Response {
        let request = CatServiceApiRequest(page: page, limit: limit)
        print(request.url)
        print(request.queryItems)
        do {
            let response = try await networkService.request(request)
            switch response {
            case .success(let data):
                return data
            case .failure(let error):
                throw error
            }
        } catch let error {
            throw error
        }
    }
}
