//
//  DetailViewController.swift
//  SynchronyApp
//
//  Created by Sulabh Agarwal on 6/9/24.
//

import UIKit

class DetailViewController: UIViewController {
    private let cat: CatBreed
    
    // UI Elements
    private let nameLabel = UILabel()
    private let descriptionLabel = UILabel()
    private let temperamentLabel = UILabel()
    private let originLabel = UILabel()
    private let lifeSpanLabel = UILabel()
    private let wikipediaButton = UIButton(type: .system)
    private let stackView = UIStackView()

    init(cat: CatBreed) {
        self.cat = cat
        super.init(nibName: nil, bundle: nil)
    }

    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .white
        
        setupViews()
        setupLayout()
        loadCatData()
    }

    private func setupViews() {
        // Configure UI elements
        nameLabel.font = UIFont.boldSystemFont(ofSize: 24)
        nameLabel.textAlignment = .center
        
        descriptionLabel.font = UIFont.systemFont(ofSize: 16)
        descriptionLabel.numberOfLines = 0
        descriptionLabel.textAlignment = .left
        temperamentLabel.numberOfLines = 0

        wikipediaButton.setTitle("View on Wikipedia", for: .normal)
        wikipediaButton.addTarget(self, action: #selector(openWikipedia), for: .touchUpInside)
                
        // Stack view for better layout
        stackView.axis = .vertical
        stackView.spacing = 16
        stackView.alignment = .fill
        
        // Add UI elements to the stack view
        stackView.addArrangedSubview(nameLabel)
        // stackView.addArrangedSubview(imageView)
        stackView.addArrangedSubview(descriptionLabel)
        stackView.addArrangedSubview(temperamentLabel)
        stackView.addArrangedSubview(originLabel)
        stackView.addArrangedSubview(lifeSpanLabel)
        stackView.addArrangedSubview(wikipediaButton)
        
        // Add stack view to the main view
        view.addSubview(stackView)
    }

    private func setupLayout() {
        // Enable Auto Layout
        stackView.translatesAutoresizingMaskIntoConstraints = false

        // Set up constraints
        NSLayoutConstraint.activate([
            stackView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 20),
            stackView.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
            stackView.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20)
        ])
        
    }

    private func loadCatData() {
        // Set the cat data to the UI elements
        nameLabel.text = cat.name
        descriptionLabel.text = cat.description

        temperamentLabel.attributedText = makeBoldLabel(for: "Temperament: ", value: cat.temperament)
        originLabel.attributedText = makeBoldLabel(for: "Origin: ", value: cat.origin)
        lifeSpanLabel.attributedText = makeBoldLabel(for: "Life Span: ", value: cat.life_span)
        
    }
    
    @objc private func openWikipedia() {
        if let urlString = cat.wikipedia_url, let url = URL(string: urlString) {
            UIApplication.shared.open(url)
        }
    }
    
    /// Helper method to create an attributed string with a bold key and regular value.
    /// - Parameters:
    ///   - key: The key part of the label that should be bold.
    ///   - value: The value part of the label that should remain regular.
    /// - Returns: An attributed string with the specified styles.
    private func makeBoldLabel(for key: String, value: String?) -> NSAttributedString {
        let boldFont = UIFont.boldSystemFont(ofSize: 16)
        let regularFont = UIFont.systemFont(ofSize: 16)
        
        let boldAttributes: [NSAttributedString.Key: Any] = [
            .font: boldFont
        ]
        
        let regularAttributes: [NSAttributedString.Key: Any] = [
            .font: regularFont
        ]
        let boldString = NSMutableAttributedString(string: key, attributes: boldAttributes)
        let regularString = NSAttributedString(string: value ?? "", attributes: regularAttributes)
        
        boldString.append(regularString)
        return boldString
    }
}
