//
//  ListViewController.swift
//  SynchronyApp
//  Created by Sulabh Agarwal on 6/9/24.
//

import UIKit

/// ListViewController manages the display and interaction with a list of cat breeds.
class ListViewController: UITableViewController {

    // MARK: - Properties
    private var viewModel: ListViewModel
    var nextAction: ((CatBreed) -> ())?
    var navigationItemAction: (() -> ())?

    // MARK: - Initialization
    
    /// Initializes a new ListViewController with an optional ViewModel.
    /// - Parameter viewModel: The ViewModel managing the data and logic for this view controller.
    init(viewModel: ListViewModel = ListViewModel()) {
        self.viewModel = viewModel
        super.init(style: .plain)
        self.viewModel.delegate = self
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    // MARK: - View Lifecycle

    override func viewDidLoad() {
        super.viewDidLoad()
        configureTableView()
        configureNavigationBar()
        Task {
            // initiate fetching data
            await self.viewModel.fetchCatList()
        }
    }

    // MARK: - UI Configuration
    
    /// Configures the table view's appearance and registers cells.
    fileprivate func configureTableView() {
        tableView.backgroundColor = .white
        tableView.tableFooterView = UIView()
        tableView.register(CatViewCell.self, forCellReuseIdentifier: CatViewCell.reuseIdentifier)
        tableView.register(LoadingCell.self, forCellReuseIdentifier: LoadingCell.reuseIdentifier)

    }
    
    fileprivate func configureNavigationBar() {
        let profileButton = UIBarButtonItem(title: "Profile", style: .plain, target: self, action: #selector(openProfile))
        navigationItem.rightBarButtonItem = profileButton
    }
    
    @objc func openProfile() {
        navigationItemAction?()
    }

}

// MARK: - UITableViewDataSource

extension ListViewController {
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        viewModel.allCatList.count +  (viewModel.state == .loading ? 1 : 0)
    }

    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if indexPath.row < viewModel.allCatList.count {
            guard let cell = tableView.dequeueReusableCell(withIdentifier: CatViewCell.reuseIdentifier, for: indexPath) as? CatViewCell else { return UITableViewCell() }
            cell.bindWithData(cat: viewModel.allCatList[indexPath.row])
            return cell
        } else {
            guard let cell = tableView.dequeueReusableCell(withIdentifier: LoadingCell.reuseIdentifier, for: indexPath) as? LoadingCell else { return UITableViewCell() }
            return cell
        }
    }
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let selected = viewModel.allCatList[indexPath.row]
        nextAction?(selected)
    }
    
    override func tableView(_ tableView: UITableView, willDisplay cell: UITableViewCell, forRowAt indexPath: IndexPath) {
        if indexPath.row == viewModel.allCatList.count - 1 {
            Task {
                await viewModel.fetchCatList()
            }
        }
    }
}

// MARK: - RequestDelegate

extension ListViewController : RequestDelegate {
    
    /// Updates the view based on the new state from the ViewModel.
    /// - Parameter viewState: The new state of the ViewModel.
    func didUpdate(viewState: ListViewState) {
        switch viewState {
        case .idle:
            break
        case .loading:
            DispatchQueue.main.async {
                self.tableView.reloadData()
            }
        case .sucess(_):
            DispatchQueue.main.async {
                self.tableView.reloadData()
            }

        case .finished:
            DispatchQueue.main.async {
                self.tableView.reloadData()
            }
            
        case .error(let error):
            // Log error and handle UI for error scenario
            print(error)
            break
        }
    }
}

