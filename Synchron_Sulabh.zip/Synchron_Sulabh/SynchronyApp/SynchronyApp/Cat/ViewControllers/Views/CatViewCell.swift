//
//  CatViewCell.swift
//  SynchronyApp
//
//  Created by Sulabh Agarwal on 6/9/24.
//

import UIKit

class CatViewCell: UITableViewCell {

    var nameLabel: UILabel = {
        let label = UILabel()
        label.numberOfLines = 0
        label.font = .boldSystemFont(ofSize: 18)
        label.textColor = .label
        label.translatesAutoresizingMaskIntoConstraints = false
        return label
    }()
    
    var originLabel: UILabel = {
        let label = UILabel()
        label.font = .systemFont(ofSize: 16)
        label.textColor = .label
        label.translatesAutoresizingMaskIntoConstraints = false
        return label
    }()
    
    var lifeSpanLabel: UILabel = {
        let label = UILabel()
        label.font = .systemFont(ofSize: 16)
        label.textColor = .label
        label.translatesAutoresizingMaskIntoConstraints = false
        return label
    }()
    
    var childFriendlyLabel: UILabel = {
        let label = UILabel()
        label.font = .systemFont(ofSize: 16)
        label.textColor = .label
        label.translatesAutoresizingMaskIntoConstraints = false
        return label
    }()
    
    var energyLevelLabel: UILabel = {
        let label = UILabel()
        label.font = .systemFont(ofSize: 16)
        label.textColor = .label
        label.translatesAutoresizingMaskIntoConstraints = false
        return label
    }()

    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)

        contentView.addSubview(nameLabel)
        contentView.addSubview(originLabel)
        contentView.addSubview(lifeSpanLabel)
        contentView.addSubview(childFriendlyLabel)
        contentView.addSubview(energyLevelLabel)
        
        setupConstraints()
    }
    
    private func setupConstraints() {
        // Enable Auto Layout
        nameLabel.translatesAutoresizingMaskIntoConstraints = false
        originLabel.translatesAutoresizingMaskIntoConstraints = false
        lifeSpanLabel.translatesAutoresizingMaskIntoConstraints = false
        childFriendlyLabel.translatesAutoresizingMaskIntoConstraints = false
        energyLevelLabel.translatesAutoresizingMaskIntoConstraints = false
        
        // Define constraints
        NSLayoutConstraint.activate([
            nameLabel.topAnchor.constraint(equalTo: contentView.topAnchor, constant: 8),
            nameLabel.leadingAnchor.constraint(equalTo: contentView.leadingAnchor, constant: 8),
            nameLabel.trailingAnchor.constraint(equalTo: contentView.trailingAnchor, constant: -8),
            
            originLabel.topAnchor.constraint(equalTo: nameLabel.bottomAnchor, constant: 8),
            originLabel.leadingAnchor.constraint(equalTo: contentView.leadingAnchor, constant: 8),
            originLabel.trailingAnchor.constraint(equalTo: contentView.trailingAnchor, constant: -8),
            
            lifeSpanLabel.topAnchor.constraint(equalTo: originLabel.bottomAnchor, constant: 8),
            lifeSpanLabel.leadingAnchor.constraint(equalTo: contentView.leadingAnchor, constant: 8),
            lifeSpanLabel.trailingAnchor.constraint(equalTo: contentView.trailingAnchor, constant: -8),
            
            childFriendlyLabel.topAnchor.constraint(equalTo: lifeSpanLabel.bottomAnchor, constant: 8),
            childFriendlyLabel.leadingAnchor.constraint(equalTo: contentView.leadingAnchor, constant: 8),
            childFriendlyLabel.trailingAnchor.constraint(equalTo: contentView.trailingAnchor, constant: -8),
            
            energyLevelLabel.topAnchor.constraint(equalTo: childFriendlyLabel.bottomAnchor, constant: 8),
            energyLevelLabel.leadingAnchor.constraint(equalTo: contentView.leadingAnchor, constant: 8),
            energyLevelLabel.trailingAnchor.constraint(equalTo: contentView.trailingAnchor, constant: -8),
            energyLevelLabel.bottomAnchor.constraint(equalTo: contentView.bottomAnchor, constant: -8)
        ])
    }
    
    func bindWithData(cat: CatBreed) {
        nameLabel.text = cat.name
        originLabel.text = "Origin: \(cat.origin ?? "")"
        lifeSpanLabel.text = "Life Span: \(cat.life_span ?? "-") years"
        childFriendlyLabel.text = "Child Friendly: \(cat.child_friendly ?? 0)"
        energyLevelLabel.text = "Energy Level: \(cat.energy_level ?? 0)"
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}


class LoadingCell: UITableViewCell {
    override var intrinsicContentSize: CGSize {
        return .zero
    }

    private let activityIndicator: UIActivityIndicatorView = {
        let activityIndicator = UIActivityIndicatorView(style: .medium)
        activityIndicator.translatesAutoresizingMaskIntoConstraints = false
        activityIndicator.color = .gray // Customize the color here
        return activityIndicator
    }()
    
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        contentView.addSubview(activityIndicator)
        setupConstraints()
        activityIndicator.startAnimating()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    private func setupConstraints() {
        NSLayoutConstraint.activate([
            activityIndicator.centerXAnchor.constraint(equalTo: contentView.centerXAnchor),
            activityIndicator.centerYAnchor.constraint(equalTo: contentView.centerYAnchor),
            // Ensure the contentView has a minimum height to avoid zero-height warnings
            contentView.heightAnchor.constraint(greaterThanOrEqualToConstant: 44)
        ])
    }
}
