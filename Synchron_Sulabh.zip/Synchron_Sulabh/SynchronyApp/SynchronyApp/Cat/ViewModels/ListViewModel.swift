//
//  ListViewModel.swift
//  SynchronyApp
//  Created by Sulabh Agarwal on 6/9/24.
//

import Foundation

// Protocol to be implemented by delegates to handle state updates
protocol RequestDelegate {
    func didUpdate(viewState:ListViewState)
}

// Enum representing different states of the view
enum ListViewState: Equatable {
    case idle
    case loading
    case sucess(CatServiceApiRequest.Response)
    case finished
    case error(Error)
    
    static func == (lhs: ListViewState, rhs: ListViewState) -> Bool {
        switch (lhs, rhs) {
        case (.idle, .idle):
            return true
        case (.loading, .loading):
            return true
        case (.sucess(let lhsResponse), .sucess(let rhsResponse)):
            return lhsResponse == rhsResponse
        case (.finished, .finished):
            return true
        case (.error(let lhsError), .error(let rhsError)):
            return lhsError.localizedDescription == rhsError.localizedDescription
        default:
            return false
        }
    }

}

// ViewModel class to handle fetching and managing cat list data
class ListViewModel {
    
    var delegate: RequestDelegate?
    var state: ListViewState {
        didSet{
            delegate?.didUpdate(viewState: state)
        }
    }
    
    var allCatList = CatList()
    private var currentPage = 0
    private let limit = 10
    // MARK: Dependencies
    private let catService: CatServiceProtocol
    
    init(service: CatServiceProtocol = CatService()) {
        self.catService = service
        self.state = .idle
    }
    
    /// Method to fetch cat list asynchronously
    func fetchCatList() async {
        guard self.state != .loading, self.state != .finished else {
            return
        }
        self.state = .loading
        do {
            let result = try await self.catService.fetchCatList(page: currentPage, limit: limit)
            guard result.count > 0 else {
                self.state = .finished
                return
            }
            self.allCatList.append(contentsOf: result) // Append new data to the list
            self.currentPage += 1
            self.state = .sucess(result)
        } catch let error {
            self.state = .error(error)
        }
    }
}


