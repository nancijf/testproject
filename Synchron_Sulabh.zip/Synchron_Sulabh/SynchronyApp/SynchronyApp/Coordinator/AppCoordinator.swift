//
//  AppCoordinator.swift
//  Created by Sulabh Agarwal

import UIKit
import SwiftUI

// MARK: - NavigationCoordinator Protocol

/// A protocol defining the basic navigation methods and properties for coordinators.
protocol NavigationCoordinator: AnyObject {
    var navigationController: UINavigationController { get set }
    func start()
    func end()
}

// MARK: - AppCoordinator Class

/// The main coordinator responsible for managing the application's navigation flow.
class AppCoordinator: NavigationCoordinator {
    
    // MARK: - Nested Types
    
    /// Enum representing different screens in the application.
    enum Screen {
        case CatList
        case CatDetail(breed: CatBreed)
        case Profile
    }
    
    // MARK: - Properties
    
    var navigationController: UINavigationController
    private let window: UIWindow
    
    // MARK: - Initialization
    
    /// Initializes the AppCoordinator with a navigation controller and window.
    ///
    /// - Parameters:
    ///   - navigationController: The main navigation controller.
    ///   - window: The application's main window.
    init(navigationController: UINavigationController, window: UIWindow) {
        self.navigationController = navigationController
        self.window = window
    }
    
    // MARK: - Navigation
    
    /// Returns the view controller for the given screen.
    ///
    /// - Parameter screen: The screen to navigate to.
    /// - Returns: A view controller for the specified screen.
    func viewController(screen: Screen) -> UIViewController {
        switch screen {
        case .CatList:
            let vc = ListViewController()
            vc.nextAction = { cat in
                self.next(.CatDetail(breed: cat))
            }
            vc.navigationItemAction = {
                self.next(.Profile)
            }
            return vc
        case .CatDetail(let cat):
            let vc = DetailViewController(cat: cat)
            return vc
        case .Profile:
            let profileView = ProfileView()
            let hostingController = UIHostingController(rootView: profileView)
            return hostingController
        }
    }
    
    /// Starts the coordinator by setting up the initial view controller.
    func start() {
        self.navigationController = UINavigationController(rootViewController: viewController(screen: .CatList))
        window.rootViewController = self.navigationController
        window.makeKeyAndVisible()
    }
    
    /// Navigates to the next screen.
    ///
    /// - Parameter screen: The screen to navigate to. If `nil`, no action is taken.
    func next(_ screen: Screen? = nil) {
        guard let screen = screen else {
            return
        }
        self.navigationController.pushViewController(viewController(screen: screen), animated: true)
    }
    
    /// Ends the coordinator. This implementation is currently empty.
    func end() { }
}
