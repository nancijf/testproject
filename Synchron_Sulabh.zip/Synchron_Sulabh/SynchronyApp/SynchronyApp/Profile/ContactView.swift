//
//  ContactView.swift
//  SynchronyApp
//
//  Created by Sulabh Agarwal on 6/11/24.
//

import SwiftUI

struct ContactView: View {
    let contact: Contact

    var body: some View {
        VStack {
            HStack {
                // LinkedIn link
                if let linkedinURL = URL(string: "https://www.linkedin.com/in/sulabh191/") {
                    Link("linkedin profile", destination: linkedinURL)
                        .foregroundColor(.blue)
                }
                Text(" | ")
                // Phone link
                if let phoneURL = URL(string: "tel:\(contact.phone)") {
                    Link(contact.phone, destination: phoneURL)
                        .foregroundColor(.blue)
                }
            }
            .multilineTextAlignment(.center)
            .foregroundColor(.gray)
            
            // Email link
            if let emailURL = URL(string: "mailto:\(contact.email)") {
                Link(contact.email, destination: emailURL)
                    .foregroundColor(.blue)
            }
        }
    }
}
