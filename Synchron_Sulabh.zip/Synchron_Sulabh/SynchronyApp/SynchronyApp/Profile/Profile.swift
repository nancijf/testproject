//
//  Profile.swift
//  SynchronyApp
//
//  Created by Sulabh Agarwal on 6/10/24.
//

import Foundation

struct Profile: Codable {
    let name: String
    let contact: Contact
    let experience: [Experience]
    let education: Education
}

struct Contact: Codable {
    let linkedin: String
    let phone: String
    let email: String
}

struct Experience: Codable, Identifiable, Hashable {
    var id = UUID().uuidString // Add a unique identifier
    let title: String
    let company: String
    let location: String
    let date: String
    let highlights: [String]
    
    // Custom initializer to generate UUID
    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        self.id = UUID().uuidString // Generate a new UUID
        self.title = try container.decode(String.self, forKey: .title)
        self.company = try container.decode(String.self, forKey: .company)
        self.location = try container.decode(String.self, forKey: .location)
        self.date = try container.decode(String.self, forKey: .date)
        self.highlights = try container.decode([String].self, forKey: .highlights)
    }
}

struct Education: Codable {
    let degree: String
    let university: String
    let location: String
    let date: String
    let field: String
}
