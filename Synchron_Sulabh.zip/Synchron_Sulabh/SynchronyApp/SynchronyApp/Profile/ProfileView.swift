//
//  ProfileView.swift
//  SynchronyApp
//
//  Created by Sulabh Agarwal on 6/10/24.
//

import SwiftUI

class ProfileViewModel: ObservableObject {
    @Published var profile: Profile?
    
    init() {
        if let url = Bundle.main.url(forResource: "profile", withExtension: "json") {
            do {
                let data = try Data(contentsOf: url)
                let decoder = JSONDecoder()
                self.profile = try decoder.decode(Profile.self, from: data)
            } catch {
                print("Error decoding JSON: \(error)")
            }
        }
    }
}

struct ProfileView: View {
    @ObservedObject var viewModel = ProfileViewModel()
    
    var body: some View {
        ScrollView {
            VStack(spacing: 20) {
                // Check if profile is loaded
                if let profile = viewModel.profile {

                    HStack(spacing: 15) {
                        // Static Profile Image from assets
                        Image("sulabh")
                            .resizable()
                            .scaledToFill()
                            .frame(width: 100, height: 100)
                            .clipShape(Circle())
                        
                        // Profile Name
                        Text(profile.name)
                            .font(.title)
                            .fontWeight(.bold)
                    }
                    .padding(.bottom, 20)

                    ContactView(contact: profile.contact)
                    
                    VStack(alignment: .leading, spacing: 10) {
                        Text("Experience")
                            .font(.title2)
                            .fontWeight(.bold)
                            .padding(.bottom, 5)
                        
                        ForEach(Array(profile.experience.enumerated()), id: \.element)  { index, experience in
                            VStack(alignment: .leading, spacing: 5) {
                                Text(experience.title)
                                    .font(.headline)
                                    .fontWeight(.semibold)
                                
                                Text("\(experience.company), \(experience.location) \(experience.date)")
                                    .font(.subheadline)
                                    .foregroundColor(.gray)
                                
                                ForEach(experience.highlights, id: \.self) { highlight in
                                    Text("• \(highlight)")
                                        .font(.system(size: 14))
                                }
                            }
                            .padding(.bottom, 10)
                        }
                    }
                    
                } else {
                    Text("Loading...")
                }
            }
            .padding()
        }
    }
}

