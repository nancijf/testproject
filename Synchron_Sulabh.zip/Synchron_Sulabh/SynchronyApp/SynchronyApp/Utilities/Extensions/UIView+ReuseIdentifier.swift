//
//  UIView+ReuseIdentifier.swift
//  Created by Sulabh Agarwal on 07/11/24.
//

import UIKit

extension UITableViewCell {

    static var reuseIdentifier: String {
        "\(String(describing: self))"
    }
}
