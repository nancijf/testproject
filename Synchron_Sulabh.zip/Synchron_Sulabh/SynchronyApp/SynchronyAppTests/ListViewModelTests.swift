//
//  ListViewModelTests.swift
//  SynchronyAppTests
//
//  Created by Sulabh Agarwal on 6/11/24.
//

import XCTest
@testable import SynchronyApp

class MockCatService: CatServiceProtocol {
    var shouldReturnError = false
    var fetchCatListResult: [CatBreed] = []
    
    func fetchCatList(page: Int, limit: Int) async throws -> [CatBreed] {
        if shouldReturnError {
            throw NSError(domain: "TestError", code: 1, userInfo: nil)
        } else {
            return fetchCatListResult
        }
    }
}


class ListViewModelTests: XCTestCase {
    
    var viewModel: ListViewModel!
    var mockCatService: MockCatService!
    
    override func setUpWithError() throws {
        mockCatService = MockCatService()
        viewModel = ListViewModel(service: mockCatService)
    }

    override func tearDownWithError() throws {
        viewModel = nil
        mockCatService = nil
    }
    
    func testFetchCatListSuccess() async throws {
        // Arrange
        let cat = CatBreed(id: "id01", name: "CatName", description: "descreption", life_span: "1-2", temperament: "3", origin: "Egypt", wikipedia_url: "", adaptability: 1, affection_level: 3, child_friendly: 4, dog_friendly: 4, energy_level: 5, grooming: 2, health_issues: 1, intelligence: 2, shedding_level: 2, social_needs: 3, stranger_friendly: 1, vocalisation: 1)
        mockCatService.fetchCatListResult = [cat]

        // Act
        await viewModel.fetchCatList()

        // Assert
        XCTAssertEqual(viewModel.allCatList, [cat])
        XCTAssertEqual(viewModel.state, .sucess([cat]))
    }
    
    func testFetchCatListError() async throws {
        // Arrange
        mockCatService.shouldReturnError = true

        // Act
        await viewModel.fetchCatList()

        // Assert
        if case .error(let error) = viewModel.state {
            XCTAssertEqual(error.localizedDescription, "The operation couldn’t be completed. (TestError error 1.)")
        } else {
            XCTFail("Expected error state")
        }
    }
    
    func testFetchCatListEmptyResult() async throws {
        // Arrange
        mockCatService.fetchCatListResult = []

        // Act
        await viewModel.fetchCatList()

        // Assert
        XCTAssertEqual(viewModel.state, .finished)
    }
    
    func testFetchCatListPagination() async throws {
        // Arrange
        let catsPage1 = [
            CatBreed(id: "id01", name: "CatName", description: "descreption", life_span: "1-2", temperament: "3", origin: "Egypt", wikipedia_url: "", adaptability: 1, affection_level: 3, child_friendly: 4, dog_friendly: 4, energy_level: 5, grooming: 2, health_issues: 1, intelligence: 2, shedding_level: 2, social_needs: 3, stranger_friendly: 1, vocalisation: 1),
            CatBreed(id: "id02", name: "second", description: "descreption", life_span: "1-2", temperament: "3", origin: "US", wikipedia_url: "", adaptability: 1, affection_level: 3, child_friendly: 4, dog_friendly: 4, energy_level: 5, grooming: 2, health_issues: 1, intelligence: 2, shedding_level: 2, social_needs: 3, stranger_friendly: 1, vocalisation: 1)
        ]
        let catsPage2 = [
            CatBreed(id: "id03", name: "CatName3", description: "descreption", life_span: "1-2", temperament: "3", origin: "Egypt", wikipedia_url: "", adaptability: 1, affection_level: 3, child_friendly: 4, dog_friendly: 4, energy_level: 5, grooming: 2, health_issues: 1, intelligence: 2, shedding_level: 2, social_needs: 3, stranger_friendly: 1, vocalisation: 1)]
        
        mockCatService.fetchCatListResult = catsPage1
        
        // Act
        await viewModel.fetchCatList()
        
        mockCatService.fetchCatListResult = catsPage2
        
        await viewModel.fetchCatList()
        
        // Assert
        XCTAssertEqual(viewModel.allCatList.count, 3)
        XCTAssertEqual(viewModel.allCatList[0], catsPage1[0])
        XCTAssertEqual(viewModel.allCatList[2], catsPage2[0])
    }
}
