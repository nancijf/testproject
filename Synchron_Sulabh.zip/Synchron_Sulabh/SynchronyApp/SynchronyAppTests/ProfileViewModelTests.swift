//
//  ProfileViewModelTests.swift
//  SynchronyAppTests
//
//  Created by Sulabh Agarwal on 6/11/24.
//

import XCTest
@testable import SynchronyApp

class ProfileViewModelTests: XCTestCase {
    
    var viewModel: ProfileViewModel!
    
    override func setUpWithError() throws {
        viewModel = ProfileViewModel()
    }
    
    override func tearDownWithError() throws {
        viewModel = nil
    }
    
    func testProfileLoading() throws {
        
        XCTAssertNotNil(viewModel.profile, "Profile should be loaded")
        XCTAssertEqual(viewModel.profile?.name, "Sulabh Agarwal")
    }
}

